/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main() {
    printf("Hola, vamos a pasar de forma binómica a forma polar\n");
    printf("Para empezar, ingrese el valor de la parte real: ");
    
    float real1, imaginaria;
    scanf("%f", &real1);
    
    printf("Ahora introduzca la parte imaginaria: ");
    scanf("%f", &imaginaria);
    
    float modulo = sqrtf(real1 * real1 + imaginaria * imaginaria);
    float angulo = atan2f(imaginaria, real1) * 180.0f / M_PI;
    
    printf("Tu número en forma polar es %.2f y tu ángulo es %.2f\n", modulo, angulo);
    
    return 0;
}
